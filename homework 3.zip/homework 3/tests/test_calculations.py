"""
Tests addition and history management functionalities in the Calculations class.
"""

import pytest
from calculator.calculations import Calculations
from calculator.calculation import Calculation

def test_add_and_retrieve_calculation():
    """Tests adding a calculation and retrieving it from history."""
    Calculations.clear_history()  # Ensure history is empty before the test
    calc = Calculation(1, 2, 'add')
    Calculations.add_calculation(calc)
    assert Calculations.get_last_calculation() == calc

def test_clear_history():
    """Tests clearing the history and accessing empty history raises ValueError."""
    Calculations.clear_history()  # Clear history to ensure it's empty
    with pytest.raises(ValueError):
        Calculations.get_last_calculation()
