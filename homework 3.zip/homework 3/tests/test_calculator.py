"""
This module contains unit tests for the Calculator class defined in the calculator package.
It tests all basic arithmetic operations (addition, subtraction, multiplication, and division)
including edge cases such as division by zero."""

import pytest
from calculator.calculator import Calculator

def test_add():
    """Test addition with positive integers."""
    assert Calculator.add(1, 2) == 3

def test_subtract():
    """Test subtraction with positive integers."""
    assert Calculator.subtract(2, 1) == 1

def test_multiply():
    """Test multiplication with positive integers."""
    assert Calculator.multiply(3, 2) == 6

def test_divide():
    """Test division with non-zero divisor."""
    assert Calculator.divide(10, 2) == 5

def test_divide_zero():
    """Ensure division by zero raises ValueError."""
    with pytest.raises(ValueError):
        Calculator.divide(10, 0)

# Fixture for Calculator operations
@pytest.fixture
def setup_calculator():
    """Provides a Calculator instance for testing."""
    return Calculator()

@pytest.mark.parametrize("a, b, expected", [
    (1, 2, 3),
    (5, 5, 10),
    (2, 3, 5)
])
def test_add_parameterized(setup_calculator, a, b, expected):
    """Test addition with parameterized values."""
    assert setup_calculator.add(a, b) == expected

@pytest.mark.parametrize("a, b, expected", [
    (2, 2, 0),
    (5, 3, 2),
    (10, 5, 5)
])
def test_subtract_parameterized(setup_calculator, a, b, expected):
    """Test subtraction with parameterized values."""
    assert setup_calculator.subtract(a, b) == expected

@pytest.mark.parametrize("a, b", [
    (1, 0),
    (10, 0)
])
def test_divide_by_zero_parameterized(a, b):
    """Test division by zero with parameterized values to ensure it raises ValueError."""
    with pytest.raises(ValueError):
        Calculator.divide(a, b)
