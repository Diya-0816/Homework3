"""
Tests the execution of arithmetic operations within the Calculation class.
"""

import pytest
from calculator.calculation import Calculation

def test_execute_addition():
    """Tests addition using Calculation class to ensure correct execution and result."""
    calc = Calculation(1, 2, 'add')
    assert calc.execute() == 3
