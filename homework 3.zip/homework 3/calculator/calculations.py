"""Provides functionality to manage and track a history of arithmetic calculations."""

from typing import List
from calculator.calculation import Calculation

class Calculations:
    """Manages a history of calculations as a list of Calculation instances."""

    history: List[Calculation] = []

    @classmethod
    def add_calculation(cls, calculation: Calculation) -> None:
        """Adds a new Calculation instance to the calculation history."""
        cls.history.append(calculation)

    @classmethod
    def get_last_calculation(cls) -> Calculation:
        """Returns the last calculation or raises an error if history is empty."""
        if not cls.history:
            raise ValueError("No calculations in history.")
        return cls.history[-1]

    @classmethod
    def clear_history(cls) -> None:
        """Clears all entries from the calculation history."""
        cls.history.clear()
