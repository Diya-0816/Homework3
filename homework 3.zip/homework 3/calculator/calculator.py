class Calculator:
    """
    Provides static methods for basic arithmetic operations: addition, subtraction,
    multiplication, and division with zero-division error handling.
    """

    @staticmethod
    def add(a: float, b: float) -> float:
        """Adds two numbers and returns the result. Useful for quick, simple addition of floating point numbers."""
        return a + b

    @staticmethod
    def subtract(a: float, b: float) -> float:
        """Subtracts the second number from the first and returns the difference. Handles floating point precision."""
        return a - b

    @staticmethod
    def multiply(a: float, b: float) -> float:
        """Multiplies two numbers and returns the product. Ideal for scaling values or calculating areas."""
        return a * b

    @staticmethod
    def divide(a: float, b: float) -> float:
        """Divides the first number by the second, raises ValueError on division by zero. Ensures safe division operations."""
        if b == 0:
            raise ValueError("Cannot divide by zero.")
        return a / b
