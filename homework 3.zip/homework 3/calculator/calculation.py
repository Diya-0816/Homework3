"""This module provides the Calculation class to execute basic arithmetic operations based on given operands and operation type."""

from .calculator import Calculator

class Calculation:
    """Represents an arithmetic calculation based on two operands and an operation.

    Attributes:
        operand1 (float): The first operand in the calculation.
        operand2 (float): The second operand in the calculation.
        operation (str): The type of arithmetic operation to be performed.
    """

    def __init__(self, operand1: float, operand2: float, operation: str):
        """Initializes a new instance of the Calculation class.

        Args:
            operand1 (float): The first number in the calculation.
            operand2 (float): The second number in the calculation.
            operation (str): The arithmetic operation to be performed, e.g., 'add', 'subtract', 'multiply', 'divide'.
        """
        self.operand1 = operand1
        self.operand2 = operand2
        self.operation = operation

    def execute(self) -> float:
        """Executes the arithmetic operation based on the initialized operands and operation type.

        Returns:
            float: The result of the arithmetic operation.

        Raises:
            ValueError: If an invalid operation type is specified.
        """
        if self.operation == 'add':
            return Calculator.add(self.operand1, self.operand2)
        elif self.operation == 'subtract':
            return Calculator.subtract(self.operand1, self.operand2)
        elif self.operation == 'multiply':
            return Calculator.multiply(self.operand1, self.operand2)
        elif self.operation == 'divide':
            return Calculator.divide(self.operand1, self.operand2)
        else:
            raise ValueError("Invalid operation")
